# Security Policy

## Reporting a Vulnerability

Please use the following contact information for reporting a vulnerability:

- [Daniel Lemire]( https://www.teluq.ca/siteweb/univ/en/dlemire.html) - daniel@lemire.me


