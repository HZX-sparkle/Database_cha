Before submitting this PR, run `tools/clang-format.sh` on your changes. See the "Contributing" section in the README for details.

